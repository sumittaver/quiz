<?php error_reporting(-1); 
ini_set('display_errors', true); 
 ini_set('display_startup_errors', TRUE);
 include("includes/key.php"); 
 
print_r($_SESSION);

exit;


?>