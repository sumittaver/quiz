<?php error_reporting(-1); ?>
<?php ini_set('display_errors', true); ?>
<?php ini_set('display_startup_errors', TRUE); ?>

<!DOCTYPE html>
<html lang="en">
<?php include("includes/head.php"); ?>
<body>
<div class="se-pre-con"></div>
    
<div class="container">
    <div class="jumbotron">
        <h1><a href="index.php">gamerworld.com</a></h1>
        <h2>There are some technical difficulties!</h2>
        <p>sorry it seems you were trying to access a page that doesn't exist</p>
        <p><a href="index.php">Clich here to Home page</a></p>
    </div>
</div>
</body>
</html>